-Copyright Highwalker Studios 2016
-Created by Luc Highwalker

------------------------------------------------------------
HOW TO USE:
------------------------------------------------------------

-Simply attach the Ground prefab as a child to your main camera. 
It should work with the default settings, but the modifier in 
the attached script may need to be tweeked. 

-Works with any tiled texture. 

-To correctly set the modifier. Run the scene, and move the ground 
object around. If the texture moves along with the movement, the 
modifier is too low. If it moves in reverse to the movement, your 
modifier is too high. It should look as though the texture doesn't 
move at all. 

-Crediting me is not required, but would be nice.

------------------------------------------------------------

THANKS FOR DOWNLOADING!!!!

